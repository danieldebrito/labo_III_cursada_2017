window.onload = function () {
    cargarLista();
}

function refrescaLista(array) {
    var tabla = "";
    $("#tbody").html(tabla);

    for (var i = 0; i < array.length; i++) {
        tabla +=
            "<tr style='background-color:" + array[i].color + "' >"
            + "<td>" + array[i].nombre + "</td>"
            + "<td>" + array[i].apellido + "</td>"
            + "<td><button class='btn btn-primary' id='btnborrar'>Borrar</button></td>"
            + "<td><button class='btn btn-primary' id='btnmod'>Modificar</button></td>"
            + "</tr>"
    }
    $("#tbody").html(tabla);
}

function cargarLista() {
    $.ajax({
        success: function (responseText) {
            refrescaLista(JSON.parse(responseText));
        },
        type: "GET",
        url: 'http://localhost:3000/traerpersonas',
    });
}

function agregarPersona(){
var nombre = $("#nombre").val();
var apellido = $("#nombre").val();
var color = $("#color").color();

datos = {
    'nombre': nombre,
    'apellido': apellido,
    'color': color,
}

$.ajax({
    success: function(){
        cargarLista();
    },
    type: "POST",
    data: datos,
    url: 'http://localhost:3000/agregarpersona',
});
}

function baja(index){




}
