window.onload = function () {
    cargarLista();
}

function refrescaLista(array) {
    var tabla = "";
    $("#tbody").html(tabla);

    for (var i = 0; i < array.length; i++) {
        tabla +=
            "<tr style='background-color:" + array[i].color + "' >"
            + "<td>" + array[i].nombre + "</td>"
            + "<td>" + array[i].apellido + "</td>"
            + "<td><button class='btn btn-primary' id='btnborrar' onclick='baja(" + i + ")'>Borrar</button></td>"
            + "<td><button class='btn btn-primary' id='btnmod' onclick='traer(" + i + ")'>Modificar</button></td>"
            + "</tr>"
    }
    $("#tbody").html(tabla);
    $("#btnguardar").val(-1);
}

function cargarLista() {
    $.ajax({
        success: function (responseText) {
            refrescaLista(JSON.parse(responseText));
        },
        type: "GET",
        url: 'http://localhost:3000/traerpersonas',
    });
    limpiar();
}

function guardar() {
    
    if ($("#btnguardar").val() >= 0) {
        modificar($("#btnguardar").val());
        cargarLista();
        $("#btnguardar").val(-1);
    }
    if ($("#btnguardar").val() == -1 ){
        agregarPersona();
        cargarLista();
        $("#btnguardar").val(-1);
    }
}

function limpiar(){
    $("#nombre").val("");
    $("#apellido").val("");
    $("#color").val(""); 
}


function agregarPersona() {
    var nombre = $("#nombre").val();
    var apellido = $("#apellido").val();
    var color = $("#color").val();
    
    if( nombre && apellido){
    datos = {
        'nombre': nombre,
        'apellido': apellido,
        'color': color,
    }
    $.ajax({
        success: function () {
            cargarLista();
        },
        type: "POST",
        data: datos,
        url: 'http://localhost:3000/agregarpersona',
    });
}
}
function baja(index) {
    $.ajax({
        success: function () {
            cargarLista();
        },
        type: "POST",
        data: { 'indice': index },
        url: 'http://localhost:3000/eliminarpersona',
    });
}
function traer(index) {
        $.ajax({
            success: function (responseText) {
                var p = JSON.parse(responseText);
                $("#nombre").val(p.nombre);
                $("#apellido").val(p.apellido);
                $("#color").val(p.color);
                $("#btnguardar").val(index);
            },
            type: "GET",
            data: { 'indice': index },
            url: 'http://localhost:3000/traerpersona',
        });
}

function modificar(index){
    $("#btnguardar").val(index);
    var nombre = $("#nombre").val();
    var apellido = $("#apellido").val();
    var color = $("#color").val();
    
    var persona = {
        'nombre': nombre,
        'apellido': apellido,
        'color' : color,
    }
    
    data = {
        'indice': index,
        'persona': JSON.stringify(persona),
    }

    $.ajax({
        success: function () {
            cargarLista();
        },
        type: "POST",
        data: data,
        url: 'http://localhost:3000/modificarpersona',
    }); 
    
        

        localStorage.getItem();


}
