"use strict";
var SegundoParcial;
(function (SegundoParcial) {
    var Animal = /** @class */ (function () {
        function Animal(nombre, edad, patas) {
            this.nombre = nombre;
            this.edad = edad;
            this.patas = patas;
        }
        return Animal;
    }());
    SegundoParcial.Animal = Animal;
})(SegundoParcial || (SegundoParcial = {}));
