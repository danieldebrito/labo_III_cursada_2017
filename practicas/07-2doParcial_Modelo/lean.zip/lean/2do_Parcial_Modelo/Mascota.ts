/// <reference path="node_modules\@types\jquery\index.d.ts" />

namespace SegundoParcial{
    
    export abstract class Mascota extends Animal {
        public id:number;
        public tipo:ETipoMascotas;
        
        public constructor(id:number, tipo:ETipoMascotas,nombre:string,edad:number,patas:string){
            super(nombre, edad, patas);
            this.id = id;
            this.tipo = tipo;
        }
    }
    
    }