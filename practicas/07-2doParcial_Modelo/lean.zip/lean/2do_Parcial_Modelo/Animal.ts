namespace SegundoParcial{
    
    export abstract class Animal {
        public nombre:string;
        public edad:number;
        public patas:string;

        public constructor(nombre:string,edad:number,patas:string){
            this.nombre = nombre;
            this.edad = edad;
            this.patas = patas;
        }
    }
    
    }