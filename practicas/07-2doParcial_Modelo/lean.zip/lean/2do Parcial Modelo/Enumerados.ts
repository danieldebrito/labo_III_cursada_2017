namespace SegundoParcial{

export enum ETipoMascotas {
    Perro,
    Gato,
    Reptil,
    Roedor,
    Ave,
    Pez
}

}