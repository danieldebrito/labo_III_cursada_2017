namespace SegundoParcial{
    
    export class Animal {
        
    }
    
    }